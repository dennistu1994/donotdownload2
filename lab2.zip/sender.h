#pragma once
class Sender {
    public:
        int SN=0;
        int NEXT_EXPECTED_ACK=1;
};

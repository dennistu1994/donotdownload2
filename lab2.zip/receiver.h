#pragma once
class Receiver {
    public:
        int NEXT_EXPECTED_FRAME=0;
        

};
